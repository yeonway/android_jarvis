# 지금까지 확인한 핵심 분석

## 기준 원본
- 파일: JARVIS-Local-0.9.5-source-r12(3).zip
- SHA-256: 02d562020fcf75ce3472e341cb0120572b320a5fd9109d4efa236b0835879b72

## 주요 확인 사항

1. Function Tool Calling은 자유 생성 후 parser/validator 구조다.
   - grammar/GBNF/json-schema constrained decoding이 native sampler 경로에 연결된 흔적을 확인하지 못했다.
   - 따라서 structured generation 실험 가치가 높다.

2. Tiny Router는 label 생성형 라우터이며 explicit confidence calibration/entropy/margin/OOD 처리가 없다.
   - UNKNOWN fallback은 존재하지만 calibrated abstention은 아니다.

3. Tool shortlist는 `Core.toolsFor()` 중심 lexical/regex heuristic에 크게 의존한다.
   - 작은 Function model의 context를 줄이는 장점이 있으나 표현 다양성/recall 문제가 생길 수 있다.

4. Function Agent는 최대 3 step이며 동일 call 반복 억제, read-only 연속 실행 등의 보호가 존재한다.
   - 이 구조는 유지해야 한다.

5. Tool 결과 observation을 다음 model prompt에 넣는 경로가 존재한다.
   - 외부 Web/RAG/OCR/MCP 콘텐츠까지 신뢰 데이터로 취급하지 않도록 provenance/trust 분리가 필요하다.

6. 일부 Tool은 실행 후 실제 상태 검증이 존재한다.
   - 따라서 verification을 "새로 처음 도입"하는 것이 아니라 공통 contract로 일반화하는 것이 맞다.

7. 현재 `InferenceService`는 별도 process이지만 isolated process는 아니다.
   - 이번 intelligence prompt에서는 우선순위가 낮지만 향후 security hardening 후보가 될 수 있다.

8. 현재 llama.cpp/GGUF 분리 runtime을 다른 runtime으로 즉시 교체할 근거는 없다.
   - LiteRT/ExecuTorch/ONNX/MLC는 동일 S21/동일 모델 benchmark에서 우위가 입증될 때만 비교 대상.

## 아직 완료되지 않은 조사

- 2025~2026 최신 논문/프로젝트별 수치 비교
- FunctionGemma-specific structured generation compatibility
- 현재 vendored llama.cpp commit에서 grammar/speculative API 정확히 무엇이 노출되는지 전체 검증
- S21급 draft speculative의 실제 RAM/속도 손익 실측
- Tool retrieval 관련 최신 benchmark 비교
- Router calibration/OOD 최신 경량 방법 비교
- small-model tool fine-tuning 최신 benchmark 정리
- ExecuTorch/LiteRT/MLC/ONNX의 동일 조건 Android 비교

따라서 이 ZIP은 "완성 연구 보고서"가 아니라
현재까지의 분석을 Codex 구현/검증 작업으로 넘기기 위한 handoff pack이다.
