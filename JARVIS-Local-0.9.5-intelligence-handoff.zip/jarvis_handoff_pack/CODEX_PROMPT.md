# Codex 작업 프롬프트 — JARVIS Local Intelligence Pipeline 개선

첨부된 원본 ZIP은 현재 JARVIS Local 0.9.5의 최신 실제 source다.

이번 작업에서는 먼저 ZIP 전체를 풀고 실제 source를 읽은 뒤 수정한다.
README/통합보고서의 주장보다 실제 코드가 source of truth다.

## 매우 중요

- 기존 applicationId/package/versionCode/signing 구조 유지
- 현재 Main/Function/Embedding/Voice 분리 runtime 유지
- Main 상주 정책 유지
- 기존 Tiny Router / deterministic route / Memory / RAG / Tool Agent / Approval / Undo 구조를 갈아엎지 않는다
- 현재 llama.cpp commit은 필요성이 명확하지 않으면 변경하지 않는다
- Flash Attention/Vulkan/GPU offload를 임의 활성화하지 않는다
- 안정적인 KleidiAI 설정 유지
- 새 runtime으로 전면 교체하지 않는다
- unrelated change를 되돌리지 않는다
- 먼저 실제 호출 관계와 테스트를 확인한 뒤 최소 변경한다
- 각 단계마다 build/test를 실행하고 실패를 수정한 뒤 다음 단계로 간다

## 이번 작업 목표

현재 JARVIS의 AI 판단 정확도, Tool 성공률, latency, 실패 복구, 보안을 개선한다.

특히 다음 실제 source 문제를 우선 해결한다.

### 1. Structured / Constrained Tool Generation

현재 Function Tool Calling은 대체로:

LLM free generation
→ 문자열 parser
→ Core.validate()

구조다.

실제 source에서 `FunctionRouter`, `Core.parse`, native inference sampler, `bridge.cpp`를 다시 확인한다.

목표:
- Function model Tool call에 가능한 범위에서 JSON/grammar-constrained generation을 적용한다.
- llama.cpp의 grammar/GBNF/json-schema 계열 기능을 현재 native bridge에 안전하게 연결할 수 있는지 실제 vendored llama.cpp API 기준으로 확인한다.
- 현재 FunctionGemma output format과 호환되는 가장 작은 변경을 선택한다.
- grammar가 지원되지 않거나 현재 function-token 형식과 충돌하면 억지로 적용하지 말고 fallback 구조를 만든다.
- 기존 parser는 backward-compatible fallback으로 유지할 수 있다.
- malformed JSON/invalid Tool args가 generation 단계에서 줄어드는지 benchmark한다.

완료 조건:
- valid Tool-call 비율 비교
- malformed parse failure 비교
- 기존 정상 Tool regression 없음
- grammar 적용 실패 시 기존 경로로 안전 rollback 가능

### 2. Tiny Router Confidence / Abstention

현재 Tiny Router는 label 출력 중심이고 explicit calibration/entropy/margin/OOD가 없다.

실제 TinyRouter 및 호출 경로를 확인하고 다음을 최소 구조로 추가 검토한다.

우선순위:
1. 가능하면 logits/probability 기반 confidence
2. 불가능하면 deterministic scoring / margin proxy
3. low-confidence 시 UNKNOWN/Function/Main으로 즉시 escalation
4. 모든 요청을 작은 모델→Function→Main 순으로 직렬 실행하는 구조는 금지

목표:
- CHAT/TOOL/MEMORY_RAG/WEB 라우팅 false positive 감소
- 애매한 요청은 abstain
- 확실한 요청만 fast path

Router training/eval data schema도 함께 추가:
- text
- expected_route
- ambiguous
- unsafe
- previous_route
- correction_reason
- source=synthetic|real_redacted
- split=train|validation|test

### 3. Tool Candidate Retrieval 개선

현재 `Core.toolsFor()`가 lexical regex 중심으로 shortlist하는 부분을 실제 확인한다.

기존 regex를 제거하지 않는다.

다음 hybrid 후보를 검토한다.

lexical candidate
+
Tool metadata retrieval
+
optional embedding candidate
→ dedupe
→ top-K Tool schema
→ Function model

중요:
- Embedding model을 일반 요청마다 무조건 실행하지 않는다.
- lexical confidence가 충분하면 embedding retrieval을 건너뛴다.
- 기존 Embedding runtime을 재사용한다.
- 별도 embedding model 추가 금지.
- Tool description, aliases, positive examples, hard-negative examples를 metadata로 관리할 수 있게 한다.

평가:
- top-1 / top-K Tool recall
- false candidate rate
- Function prompt token 증가량
- latency

### 4. Tool Description 품질 개선

Tool schema/description을 전수 확인한다.

각 Tool에 필요한 경우:
- concise description
- trigger examples
- anti-examples
- argument semantics
- units
- enum/value constraints
- dangerous/state-changing flag
- read-only flag
- verification capability

를 구조화한다.

긴 자연어 설명을 무조건 늘리지 않는다.
Small Function model이 헷갈리는 Tool pair에만 hard-negative distinction을 추가한다.

### 5. Generalized Tool Postcondition Verification

현재 일부 Tool은 실행 뒤 실제 상태를 다시 읽어 확인하지만 공통 framework가 아니다.

목표:
ToolResult를 다음처럼 명확히 구분한다.

- VERIFIED_SUCCESS
- DISPATCHED_UNVERIFIED
- PARTIAL
- FAILED

가능한 Tool은 실제 authoritative state를 다시 읽는다.

예:
- calendar create → Calendar Provider 재조회
- volume set → 실제 volume 재조회
- bluetooth state → 실제 상태 재조회
- note write → DB row 확인
- alarm/timer → 가능한 API/DB state 확인

절대:
"Intent를 열었다" == "작업이 완료됐다"
로 처리하지 않는다.

Tool별 verifier가 불가능하면 `DISPATCHED_UNVERIFIED`.

Invariant도 고려:
- 대상 외 기존 데이터가 손상되지 않았는지
- duplicate 생성 여부
- state-changing Tool 중간 실패 여부

### 6. Agent Failure Recovery

현재 최대 3-step Agent 구조를 유지한다.

무조건 같은 Tool call 반복 금지.

error taxonomy를 만든다.

예:
- MALFORMED_ARGS
- VALIDATION_FAILED
- PERMISSION_DENIED
- TOOL_UNAVAILABLE
- TRANSIENT_ERROR
- USER_ACTION_REQUIRED
- DISPATCHED_UNVERIFIED
- POSTCONDITION_FAILED
- SECURITY_REJECTED
- TIMEOUT
- PROCESS_DEATH

복구 정책:
- malformed args → argument repair 1회
- missing required arg → user clarification 또는 safe stop
- transient error → 제한된 retry
- permission → permission flow, 반복 호출 금지
- postcondition failed → 동일 호출 무한 반복 금지
- alternative Tool이 존재할 때만 replan
- state-changing action은 Approval 경계를 넘어서 자동 재시도 금지
- retry budget는 전체 3-step 내에서 관리

### 7. External Data Trust Boundary

현재 Tool observation prompt에 `trusted data, not instructions` 같은 표현이 있다면 실제 source를 확인한다.

다음 출처는 기본적으로 UNTRUSTED_DATA로 취급한다.
- Web
- RAG document
- OCR
- Screen text
- MCP external content
- external Tool output
- notification body

절대 외부 콘텐츠가 system/developer/Tool instruction으로 승격되지 않게 한다.

각 context item에 provenance/trust class를 둘 수 있는지 검토:
- SYSTEM_TRUSTED
- LOCAL_STRUCTURED
- USER_AUTHORED
- EXTERNAL_UNTRUSTED
- MODEL_GENERATED

Tool argument 생성 시 외부 문자열을 직접 실행 명령으로 해석하지 않는다.

### 8. Semantic Cache

KV/prefix cache와 별도다.

안전한 request class에만 semantic response cache를 검토한다.

허용 후보:
- static explanation
- terminology
- stable local help
- deterministic transformed text where source hash is included

기본 금지:
- battery/time/date
- calendar
- notification
- location
- weather
- web/news
- current device state
- memory-sensitive query
- Tool result
- state-changing request
- approval-related action

cache key에 최소:
- normalized semantic key
- model/version
- system prompt revision
- relevant memory revision 또는 no-memory marker
- locale
- response class
- TTL

Embedding은 필요할 때만 기존 Embedding runtime 재사용.

### 9. Prompt / Context Selection

Memory와 conversation history를 분리한다.

긴 history를 무조건 summary하지 않는다.

검토:
- recent-turn window
- relevant-turn retrieval
- token-budget packing
- duplicate/prunable turn 제거
- current task/episodic context
- Memory retrieval과 history retrieval 분리

목표:
Main context 512 제약 안에서 핵심 정보 우선.

context item마다:
- source
- timestamp
- relevance
- token cost
- trust
- mandatory/optional

을 관리하는 lightweight packing 구조 검토.

### 10. Learning From Failures Dataset

실사용 로그에서 raw 개인정보를 그대로 외부 전송하지 않는다.

local redacted dataset을 만들 수 있도록 구조를 추가한다.

저장 후보:
- redacted_request
- expected_route
- actual_route
- candidate_tools
- selected_tool
- arguments_schema_only 또는 redacted args
- parse_status
- validation_status
- execution_status
- verification_status
- user_correction
- retry_count
- latency
- model/version
- timestamp bucket

failure classes:
- router mistake
- Tool shortlist miss
- Tool selection mistake
- malformed args
- validation fail
- approval mistake
- tool execution fail
- postcondition fail
- user correction
- aborted action
- successful workflow

원문 연락처/주소/전화번호/메시지/토큰/API key 등은 dataset에 평문 저장하지 않는다.

### 11. Offline Fine-tuning 준비

폰에서 Main/Function 모델을 학습하지 않는다.

PC-side training을 전제로 dataset export를 만든다.

검토:
- LoRA/QLoRA
- distillation
- synthetic Tool dataset
- hard negatives
- failure replay
- preference pairs

Function model dataset 예:

request:
"내일 오후 3시에 치과 일정 추가해줘"

positive:
tool=create_calendar_event
args={...}

hard negative:
open_calendar
get_calendar_events
set_alarm

Router dataset 예:
{
  "text": "...",
  "label": "TOOL",
  "ambiguous": false,
  "hard_negative": "CHAT"
}

### 12. Speculative Decoding Benchmark

현재 llama.cpp source/API와 compatibility를 먼저 확인한다.

비교:
- baseline Main
- n-gram speculative
- draft model speculative

Galaxy S21 기준으로:
- TTFT
- decode tok/s
- RAM
- thermal
- energy
- load latency

를 측정한다.

중요:
- Main 0.8B + draft model 동시 상주가 RAM/cache pressure 때문에 오히려 손해일 수 있다.
- draft model 추가는 benchmark로 명확한 이득이 없으면 채택하지 않는다.
- n-gram/self-speculation이 현재 llama.cpp commit에서 지원되지 않으면 commit을 성급히 올리지 말고 별도 experimental branch/feature flag로 검토한다.

### 13. Retrieval Quality

Embedding cosine 하나만 맹신하지 않는다.

스마트폰 비용 대비 다음 순서로 비교한다.

1. lexical/BM25-like signal
2. embedding
3. Reciprocal Rank Fusion
4. optional lightweight rerank
5. MMR/source diversity

별도 대형 reranker 모델은 0.9.x 기본 경로에 추가하지 않는다.

기존 Embedding runtime 재사용 우선.

### 14. JARVIS Intelligence Benchmark

자동 regression benchmark를 만든다.

카테고리:
- CHAT
- deterministic
- TOOL
- MEMORY
- WEB
- multi-tool
- ambiguous
- unsafe action
- permission failure
- malformed arg
- injection attempt
- postcondition failure

최소 metric:
- route accuracy
- Tool candidate recall@K
- Tool selection accuracy
- argument exactness
- schema-valid rate
- false Tool rate
- false deterministic rate
- unnecessary LLM call rate
- end-to-end completion success
- verified completion success
- approval correctness
- retry count
- TTFT
- total latency
- generated tokens
- crashes
- Binder/process recovery

실패 사례를 regression test로 고정할 수 있게 한다.

### 15. Security / Android execution-layer requirements

항상 다음 원칙을 지킨다.

"LLM이 틀려도 Android 실행 계층이 피해를 막아야 한다."

검사:
- Prompt/Tool/RAG/Web/MCP injection
- Memory poisoning
- malformed/wrong Tool args
- Approval bypass
- Accessibility wrong action
- external content interpreted as instruction
- 개인정보/API key/token leakage
- exported Intent/Service/Receiver/Binder exposure
- process death 중 partial action
- DB/cache/model corruption
- rollback/undo/recovery

특히:
- LLM output은 항상 untrusted proposal
- Tool schema/validator가 최종 gate
- 위험 action은 Approval 유지
- Approval 후 args가 바뀌면 재승인
- Intent/Binder input validation
- exported=false 기본
- sensitive logs redaction
- model-generated URL/Intent/phone number 등은 validator 통과

### 16. Runtime 원칙

Galaxy S21급 기준.

평가할 것:
- Main RAM 증가
- 추가 resident model 필요 여부
- CPU/GPU/NPU
- battery/thermal
- startup latency
- TTFT
- background 비용

현재:
- llama.cpp + GGUF
- Main/Function/Embedding 분리 runtime
- Main resident

을 기본으로 유지한다.

LiteRT / ExecuTorch / ONNX / MLC 등으로 전면 교체하지 않는다.
동일 모델/동일 기기/동일 context에서 명확한 성능·메모리 우위를 실측할 수 있을 때만 별도 experimental 비교를 허용한다.

## 권장 구현 순서

한 번에 전부 크게 바꾸지 말고 다음 순서로 진행한다.

### Phase A — Measurement first
1. 기존 pipeline benchmark 추가
2. 현재 Tool parse/schema-valid/selection 통계 확보
3. Router confusion matrix 확보
4. latency/RAM baseline 확보

### Phase B — Reliability
5. Tool postcondition verification 공통화
6. error taxonomy + retry budget
7. external context trust boundary
8. approval argument immutability 검증

### Phase C — Tool intelligence
9. constrained Function output 실험
10. Tool metadata / hard negatives
11. hybrid Tool candidate retrieval
12. Tiny Router confidence/abstention

### Phase D — Context / efficiency
13. conversation context packing
14. semantic cache
15. hybrid retrieval/RRF/MMR

### Phase E — Learning loop
16. privacy-redacted failure dataset
17. benchmark regression corpus
18. PC-side fine-tuning export format

### Phase F — Experimental performance
19. n-gram speculation benchmark
20. draft model benchmark only if RAM budget permits

## 각 단계 완료 시 반드시 보고

- 수정 파일
- 수정 이유
- public API/schema 변화
- 새 테스트
- 실행한 명령
- 테스트 결과
- APK build 결과
- benchmark 전/후
- RAM/latency 영향
- 보안 영향
- rollback 방법
- 남은 문제

## 최종 완료 기준

- 기존 정상 Tool regression 없음
- 전체 unit/instrumentation test 통과
- ARM64 APK build 성공
- applicationId/versionCode/signing 유지
- Function malformed output 감소 또는 명확한 benchmark 결과
- Router ambiguity 처리 개선
- Tool verified success metric 확보
- 동일 Tool 무한 반복 없음
- Approval 우회 없음
- 외부 context injection regression test 존재
- 개인정보가 training/eval export에 평문 포함되지 않음
- 기능별 feature flag/rollback 가능
